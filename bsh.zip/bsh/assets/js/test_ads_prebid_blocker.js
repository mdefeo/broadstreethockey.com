window.concertAdBlockDetectorLoaded = true;
